/**
 * Creates instances of nonhuman agents. Extends Agent
 * @extends Agent
 */
class Nonhuman extends Agent{
  /**
   * Constructor
   * @param {Number} x        [description]
   * @param {Number} y        [description]
   * @param {String} index    [description]
   * @param {[type]} theColor [description]
   */
  constructor (x, y, index, theColor){
		super(x, y, index);
  }
}
